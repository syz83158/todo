package com.example.android.architecture.blueprints.todoapp.statistics
import com.example.android.architecture.blueprints.todoapp.data.Task

import org.junit.Test

import org.junit.Assert.*

class StatisticsUtilsTest {


}